# Glass OS Launcher – Android-Projekt

Ein eigener, iOS-26-inspirierter Glas-Look-Launcher als Ausgangspunkt für dein Samsung Galaxy A56. Das ist ein unabhängiges Projekt und keine Apple-Software.

## Was diese erste Version kann
- Als Android-Home-App auswählbar
- Zeigt installierte Apps in einem 4-Spalten-Raster
- Suchfeld zum Filtern der Apps
- Glasartige Suchleiste und Dock
- Uhr, App-Drawer-Umschalter und dunkler blau-schwarzer Hintergrund
- Langes Drücken auf ein App-Symbol öffnet die Android-App-Info

## Grenzen dieser ersten Version
- Noch kein echter iOS-Sperrbildschirm
- Ersetzt nicht die Samsung-Statusleiste oder das System-Control-Center
- Noch keine interaktiven Android-Widgets, Ordnerbearbeitung oder iOS-Systemanimationen
- `QUERY_ALL_PACKAGES` wird benötigt, damit ein sideloaded Launcher installierte Apps auflisten kann
- Android 17 / Galaxy A56 wurde hier nicht auf einem realen Gerät getestet

## APK über GitHub bauen – nur mit dem Handy
1. Lade diese ZIP herunter und entpacke sie auf deinem Handy.
2. Öffne GitHub im Browser und erstelle ein neues, leeres Repository.
3. Lade die Dateien und Ordner aus dem entpackten Projekt hoch. Wichtig: `.github/workflows/build-apk.yml` muss genau an diesem Pfad liegen.
4. Öffne im Repository den Tab **Actions**.
5. Wähle **Build Glass OS Launcher APK** und tippe auf **Run workflow** (oder warte, bis der erste Push den Build startet).
6. Öffne den fertigen Workflow-Lauf. Unter **Artifacts** findest du `Glass-OS-Launcher-APK.zip`.
7. Lade dieses Artefakt herunter, entpacke es und installiere `app-debug.apk`.

## Als Standard-Launcher einstellen
Nach der Installation: **Einstellungen → Apps → Standard-Apps auswählen → Startbildschirm-App** und dort **Glass OS Launcher** wählen. Die Menünamen können je nach One UI-Version leicht abweichen.

## Hinweis
Der Debug-Build ist für private Tests gedacht. Android kann beim Installieren von APK-Dateien eine Sicherheitswarnung anzeigen. Installiere nur Builds aus deinem eigenen Repository.
