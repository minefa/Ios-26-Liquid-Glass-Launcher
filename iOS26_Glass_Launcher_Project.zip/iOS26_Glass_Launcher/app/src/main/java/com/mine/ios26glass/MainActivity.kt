package com.mine.ios26glass

import android.app.Activity
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.text.Editable
import android.text.TextWatcher
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LaunchApp(
    val label: String,
    val packageName: String,
    val icon: android.graphics.drawable.Drawable
)

class MainActivity : Activity() {
    private val apps = mutableListOf<LaunchApp>()
    private lateinit var root: LinearLayout
    private lateinit var grid: GridLayout
    private lateinit var search: EditText
    private lateinit var timeText: TextView
    private var allAppsVisible = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        loadApps()
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        if (::grid.isInitialized) renderApps(search.text?.toString().orEmpty())
        if (::timeText.isInitialized) updateTime()
    }

    private fun loadApps() {
        apps.clear()
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
        resolved.mapNotNull { ri ->
            val ai = ri.activityInfo?.applicationInfo ?: return@mapNotNull null
            if (ai.packageName == packageName) return@mapNotNull null
            LaunchApp(
                label = ri.loadLabel(pm).toString(),
                packageName = ai.packageName,
                icon = ri.loadIcon(pm)
            )
        }.distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
            .forEach { apps.add(it) }
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(42), dp(18), dp(20))
            background = GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(Color.rgb(10, 17, 39), Color.rgb(34, 55, 93), Color.rgb(10, 14, 28))
            )
        }

        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val greeting = TextView(this).apply {
            text = "Good evening"
            textSize = 15f
            setTextColor(Color.argb(210, 255, 255, 255))
        }
        timeText = TextView(this).apply {
            textSize = 28f
            typeface = Typeface.create("sans-serif", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.END
        }
        topRow.addView(greeting, LinearLayout.LayoutParams(0, dp(42), 1f))
        topRow.addView(timeText, LinearLayout.LayoutParams(-2, dp(42)))
        root.addView(topRow)

        val subtitle = TextView(this).apply {
            text = "GLASS  •  HOME"
            textSize = 10f
            letterSpacing = 0.22f
            setTextColor(Color.argb(165, 220, 232, 255))
            setPadding(0, dp(3), 0, dp(15))
        }
        root.addView(subtitle)

        search = EditText(this).apply {
            hint = "Search apps"
            setHintTextColor(Color.argb(175, 255, 255, 255))
            setTextColor(Color.WHITE)
            textSize = 15f
            singleLine = true
            setPadding(dp(16), 0, dp(16), 0)
            background = glassDrawable(0.22f, 0.25f)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, dp(48)).apply {
            bottomMargin = dp(16)
        })

        val sectionRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        val sectionTitle = TextView(this).apply {
            text = "Your apps"
            textSize = 19f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(Color.WHITE)
        }
        val drawerToggle = TextView(this).apply {
            text = "ALL APPS  ↗"
            textSize = 10f
            letterSpacing = 0.08f
            setTextColor(Color.rgb(210, 228, 255))
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(9), dp(12), dp(9))
            background = glassDrawable(0.18f, 0.18f)
            setOnClickListener {
                allAppsVisible = !allAppsVisible
                sectionTitle.text = if (allAppsVisible) "App Library" else "Your apps"
                renderApps(search.text?.toString().orEmpty())
            }
        }
        sectionRow.addView(sectionTitle, LinearLayout.LayoutParams(0, dp(42), 1f))
        sectionRow.addView(drawerToggle)
        root.addView(sectionRow)

        val scroll = ScrollView(this).apply {
            clipToPadding = false
            isFillViewport = false
        }
        grid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
            setPadding(0, dp(6), 0, dp(8))
        }
        scroll.addView(grid)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(7), dp(8), dp(7), dp(8))
            background = glassDrawable(0.24f, 0.3f)
        }
        val dockItems = apps.take(4)
        dockItems.forEach { app ->
            dock.addView(makeAppView(app, true), LinearLayout.LayoutParams(0, dp(68), 1f))
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(84)).apply {
            topMargin = dp(10)
        })

        val homeIndicator = View(this).apply {
            background = rounded(Color.argb(210, 255, 255, 255), 100)
        }
        root.addView(homeIndicator, LinearLayout.LayoutParams(dp(92), dp(4)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(12)
        })

        setContentView(root)
        updateTime()
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                renderApps(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) {}
        })
        renderApps("")
    }

    private fun renderApps(query: String) {
        if (!::grid.isInitialized) return
        grid.removeAllViews()
        val filtered = apps.filter { it.label.contains(query, true) }
        val shown = if (allAppsVisible || query.isNotBlank()) filtered else filtered.take(20)
        shown.forEach { app ->
            grid.addView(makeAppView(app, false), GridLayout.LayoutParams().apply {
                width = 0
                height = dp(100)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(1), dp(3), dp(1), dp(3))
            })
        }
    }

    private fun makeAppView(app: LaunchApp, compact: Boolean): View {
        val item = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(2), dp(4), dp(2), dp(4))
            isClickable = true
            isFocusable = true
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                if (launch != null) startActivity(launch)
                else Toast.makeText(this@MainActivity, "App cannot be opened", Toast.LENGTH_SHORT).show()
            }
            setOnLongClickListener {
                val i = Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                i.data = android.net.Uri.parse("package:${app.packageName}")
                startActivity(i)
                true
            }
        }
        val iconSize = if (compact) 42 else 48
        val icon = ImageView(this).apply {
            setImageDrawable(app.icon)
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = rounded(Color.argb(20, 255, 255, 255), 22)
            elevation = dp(3).toFloat()
        }
        item.addView(icon, LinearLayout.LayoutParams(dp(iconSize), dp(iconSize)))
        val label = TextView(this).apply {
            text = app.label
            textSize = if (compact) 9.5f else 10.5f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setShadowLayer(3f, 0f, 1f, Color.BLACK)
            setPadding(dp(1), dp(5), dp(1), 0)
        }
        item.addView(label, LinearLayout.LayoutParams(-1, dp(22)))
        return item
    }

    private fun updateTime() {
        timeText.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
    }

    private fun glassDrawable(alpha: Float, strokeAlpha: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(28).toFloat()
            setColor(Color.argb((alpha * 255).toInt(), 255, 255, 255))
            setStroke(dp(1), Color.argb((strokeAlpha * 255).toInt(), 255, 255, 255))
        }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(color)
        }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
